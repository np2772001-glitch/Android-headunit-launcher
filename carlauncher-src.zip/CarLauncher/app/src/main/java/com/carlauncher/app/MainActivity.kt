package com.carlauncher.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ResolveInfo
import android.media.AudioManager
import android.os.Bundle
import android.provider.CallLog
import android.view.KeyEvent
import android.view.View
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences

    private val keyMaps = "maps_pkg"
    private val keyMusic = "music_pkg"
    private val keyPhone = "phone_pkg"
    private val defaultMaps = "com.google.android.apps.maps"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)

        val mapsTile = findViewById<View>(R.id.mapsTile)
        val musicTile = findViewById<View>(R.id.musicTile)
        val phoneTile = findViewById<View>(R.id.phoneTile)

        mapsTile.setOnClickListener { openApp(keyMaps, defaultMaps) }
        mapsTile.setOnLongClickListener { chooseApp("Choose navigation app", keyMaps); true }

        musicTile.setOnClickListener { openApp(keyMusic, null) }
        musicTile.setOnLongClickListener { chooseApp("Choose Bluetooth music app", keyMusic); true }

        findViewById<View>(R.id.btnPrev).setOnClickListener { sendMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
        findViewById<View>(R.id.btnPlay).setOnClickListener { sendMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }
        findViewById<View>(R.id.btnNext).setOnClickListener { sendMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT) }

        phoneTile.setOnLongClickListener { chooseApp("Choose Bluetooth phone app", keyPhone); true }
        val btnDialer = findViewById<View>(R.id.btnDialer)
        btnDialer.setOnClickListener { openPhone() }
        btnDialer.setOnLongClickListener { chooseApp("Choose Bluetooth phone app", keyPhone); true }
        findViewById<View>(R.id.btnRecents).setOnClickListener { openRecents() }

        findViewById<View>(R.id.btnAllApps).setOnClickListener {
            chooseApp("All apps", null)
        }
    }

    override fun onResume() {
        super.onResume()
        val half = isInMultiWindowMode
        findViewById<View>(R.id.mapsTile).visibility = if (half) View.GONE else View.VISIBLE
        showChosen(R.id.mapsHint, keyMaps, "Tap to open, hold to change app")
        showChosen(R.id.musicHint, keyMusic, "Tap to open, hold to choose app")
        showChosen(R.id.phoneHint, keyPhone, "Hold Phone button to choose app")
    }

    @Deprecated("Home screen should not close on back")
    override fun onBackPressed() {
        // Do nothing: this is the home screen.
    }

    private fun showChosen(viewId: Int, key: String, fallback: String) {
        val pkg = prefs.getString(key, null)
        val text = if (pkg == null) {
            fallback
        } else {
            try {
                val label = packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0))
                "App: $label (hold to change)"
            } catch (e: Exception) {
                fallback
            }
        }
        findViewById<TextView>(viewId).text = text
    }

    private fun launchPackage(pkg: String): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return try {
            startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun openApp(key: String, default: String?) {
        val pkg = prefs.getString(key, null) ?: default
        if (pkg == null) {
            chooseApp("Choose app", key)
            return
        }
        if (!launchPackage(pkg)) {
            toast("Could not open that app. Hold the tile to choose another.")
        }
    }

    private fun openPhone() {
        val pkg = prefs.getString(keyPhone, null)
        if (pkg != null && launchPackage(pkg)) return
        try {
            startActivity(Intent(Intent.ACTION_DIAL))
        } catch (e: Exception) {
            chooseApp("Choose Bluetooth phone app", keyPhone)
        }
    }

    private fun openRecents() {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply { type = CallLog.Calls.CONTENT_TYPE }
            startActivity(intent)
        } catch (e: Exception) {
            toast("No recent calls app found. Use the Phone button.")
        }
    }

    private fun sendMediaKey(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun launchableApps(): List<ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }

    private fun chooseApp(title: String, saveKey: String?) {
        val apps = launchableApps()
        if (apps.isEmpty()) {
            toast("No apps found")
            return
        }
        val labels = apps.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(labels) { _, which ->
                val pkg = apps[which].activityInfo.packageName
                if (saveKey != null) {
                    prefs.edit().putString(saveKey, pkg).apply()
                    onResume()
                }
                launchPackage(pkg)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }
}
