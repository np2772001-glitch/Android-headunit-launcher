package com.carnowplaying.app

import android.service.notification.NotificationListenerService

// Empty on purpose: having this service enabled in "Notification access"
// is what allows the app to read the active media sessions.
class MediaListener : NotificationListenerService()
