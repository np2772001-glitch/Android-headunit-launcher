package com.carnowplaying.app

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.drawable.ColorDrawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var msm: MediaSessionManager
    private lateinit var prefs: SharedPreferences
    private var controller: MediaController? = null
    private var lastKey: String? = null
    private var seeking = false
    private var dim = false

    private var bTitle: String? = null
    private var bArtist: String? = null
    private var bPlaying = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            bTitle = intent.getStringExtra("track") ?: bTitle
            bArtist = intent.getStringExtra("artist") ?: bArtist
            if (intent.hasExtra("playing")) {
                bPlaying = intent.getBooleanExtra("playing", false)
            }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(0xFF000000.toInt()))
        setContentView(R.layout.activity_main)
        msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        prefs = getSharedPreferences("nowplaying", Context.MODE_PRIVATE)
        dim = prefs.getBoolean("dim", false)
        applyDim()

        findViewById<View>(R.id.btnPrev).setOnClickListener { previous() }
        findViewById<View>(R.id.btnPlay).setOnClickListener { playPause() }
        findViewById<View>(R.id.btnNext).setOnClickListener { next() }
        findViewById<View>(R.id.btnAccess).setOnClickListener { openAccessSettings() }
        findViewById<View>(R.id.btnDim).setOnClickListener {
            dim = !dim
            prefs.edit().putBoolean("dim", dim).apply()
            applyDim()
        }

        findViewById<SeekBar>(R.id.seek).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    findViewById<TextView>(R.id.timeNow).text = fmt(progress * 1000L)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                seeking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                val p = seekBar?.progress ?: 0
                controller?.transportControls?.seekTo(p * 1000L)
                seeking = false
            }
        })
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction("com.android.music.metachanged")
            addAction("com.android.music.playstatechanged")
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                registerReceiver(receiver, filter)
            }
        } catch (e: Exception) {
        }
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
        try {
            unregisterReceiver(receiver)
        } catch (e: Exception) {
        }
    }

    private fun applyDim() {
        findViewById<View>(R.id.root).alpha = if (dim) 0.45f else 1f
        findViewById<Button>(R.id.btnDim).text = if (dim) "Bright" else "Dim"
    }

    private fun fmt(ms: Long): String {
        val total = if (ms < 0) 0 else ms / 1000
        val m = total / 60
        val s = total % 60
        return m.toString() + ":" + (if (s < 10) "0" else "") + s.toString()
    }

    private fun isListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return enabled != null && enabled.contains(packageName)
    }

    private fun openAccessSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "This head unit has no notification access screen.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun appLabel(pkg: String): String {
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    private fun refresh() {
        val listenerOk = isListenerEnabled()
        findViewById<View>(R.id.btnAccess).visibility = if (listenerOk) View.GONE else View.VISIBLE

        var ctrl: MediaController? = null
        if (listenerOk) {
            try {
                val list = msm.getActiveSessions(ComponentName(this, MediaListener::class.java))
                ctrl = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                    ?: list.firstOrNull()
            } catch (e: Exception) {
            }
        }
        controller = ctrl

        val titleView = findViewById<TextView>(R.id.title)
        val artistView = findViewById<TextView>(R.id.artist)
        val sourceView = findViewById<TextView>(R.id.source)
        val artView = findViewById<ImageView>(R.id.art)
        val playBtn = findViewById<Button>(R.id.btnPlay)
        val seekBar = findViewById<SeekBar>(R.id.seek)
        val timeNow = findViewById<TextView>(R.id.timeNow)
        val timeTotal = findViewById<TextView>(R.id.timeTotal)

        if (ctrl != null) {
            val md = ctrl.metadata
            val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                ?: "Unknown title"
            val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                ?: ""
            val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            val ps = ctrl.playbackState
            val playing = ps?.state == PlaybackState.STATE_PLAYING

            val key = title + "|" + artist + "|" + System.identityHashCode(art)
            if (key != lastKey) {
                lastKey = key
                titleView.text = title
                artistView.text = artist
                if (art != null) artView.setImageBitmap(art) else artView.setImageDrawable(null)
            }
            sourceView.text = appLabel(ctrl.packageName)
            playBtn.text = if (playing) "Pause" else "Play"

            val durationMs = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            var posMs = ps?.position ?: 0L
            if (ps != null && playing && posMs >= 0) {
                val delta = SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime
                posMs += (delta * ps.playbackSpeed).toLong()
            }
            if (posMs < 0) posMs = 0
            if (durationMs > 0) {
                if (posMs > durationMs) posMs = durationMs
                seekBar.isEnabled = true
                seekBar.max = (durationMs / 1000).toInt()
                if (!seeking) {
                    seekBar.progress = (posMs / 1000).toInt()
                    timeNow.text = fmt(posMs)
                }
                timeTotal.text = fmt(durationMs)
            } else {
                seekBar.isEnabled = false
                seekBar.max = 1
                seekBar.progress = 0
                timeNow.text = if (playing) fmt(posMs) else "--:--"
                timeTotal.text = "--:--"
            }
        } else {
            val key = "none|" + bTitle + "|" + bArtist
            if (key != lastKey) {
                lastKey = key
                artView.setImageDrawable(null)
                if (bTitle != null) {
                    titleView.text = bTitle
                    artistView.text = bArtist ?: ""
                } else {
                    titleView.text = "Nothing playing"
                    artistView.text = ""
                }
            }
            sourceView.text = if (listenerOk) "Start music on your phone or in YT Music" else ""
            playBtn.text = if (bPlaying) "Pause" else "Play"
            seekBar.isEnabled = false
            seekBar.max = 1
            seekBar.progress = 0
            timeNow.text = "--:--"
            timeTotal.text = "--:--"
        }
    }

    private fun playPause() {
        val c = controller
        if (c != null) {
            if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
                c.transportControls.pause()
            } else {
                c.transportControls.play()
            }
        } else {
            sendMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        }
    }

    private fun next() {
        val c = controller
        if (c != null) c.transportControls.skipToNext() else sendMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    private fun previous() {
        val c = controller
        if (c != null) c.transportControls.skipToPrevious() else sendMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    private fun sendMediaKey(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
}
